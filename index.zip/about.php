<?php
include("theme-header.php");
?>
<div class="row">
    <p class="col">
    <!-- تماس با ما -->
    <section class="bg-light py-5">
        <div class="container text-center">
            <h2>تماس با ما</h2>
            
            <p>برای اطلاعات بیشتر با ما در تماس باشید.</p>
            <a href="tel:+989123456789" class="btn btn-success">تماس تلفنی</a>
        </div>
    </section>


    </footer>
    </p>
</div>
<?php
include("theme-footer.html");
?>