<?php
//$link=mysqli_connect("localhost","root","","soheil");
$link=mysqli_connect("localhost","h314793_soheil","soheil1387","h314793_soheil");

?>
